import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:time_rescue/customTextFildes.dart';
import 'package:date_field/date_field.dart';
class FamilyScreen extends StatelessWidget {
  const FamilyScreen({
    Key? key, // Corrected the parameter name
  }) : super(key: key); // Corrected the syntax

  @override
  Widget build(BuildContext context) {
    String? _selectedItem; // Moved the variable declaration here

    TextEditingController name = TextEditingController();
        TextEditingController idnumber = TextEditingController();
    TextEditingController date = TextEditingController();
    TextEditingController age = TextEditingController();
    TextEditingController type = TextEditingController();

    return Scaffold(
      appBar: AppBar(
        title: Center(child: Text("Family Information",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),)),
        ),
      body: Directionality(
        textDirection: TextDirection.ltr,
        child: SingleChildScrollView(
          child: Container(
              color: Color(0xffE8E9EB),
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 5),
            child: Container(
              color: Colors.white,
              padding: EdgeInsets.all(8),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(height: MediaQuery.sizeOf(context).height*0.05),
                  Text(
                    'Required Information ',
                    style: GoogleFonts.cairo().copyWith(fontWeight: FontWeight.bold,fontSize: 25),
                  ),
                   SizedBox(height: 10),
              
                  Container(
                    alignment: Alignment.centerRight,
                    width: MediaQuery.of(context).size.width,
                    padding: EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: DropdownButton<String>(
                      value: _selectedItem,
                      onChanged: (String? newValue) {
                        _selectedItem = newValue;
                      },
                      items: <String>[
                        'relation/type',
                        'Father',
                        'Mother',
                        'Brother',
                        'Sister'
                      ].map((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                    ),
                  ),
                  SizedBox(height: 10),
                  CustomTextFormField(
                    label: "Name",
                    controller: name,
                    keyboardType: TextInputType.text,
                  ),
                  SizedBox(height: 15),
                  CustomTextFormField(
                    label: "Identification number / Location",
                    controller: idnumber,
                    keyboardType: TextInputType.text,
                  ),
               
                                  SizedBox(height: 15),
              
                    Container(
                      height: 50,
                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.black),
                        borderRadius: BorderRadius.circular(8),
                      ),
                child:  DateTimeFormField(
                decoration: const InputDecoration(
                  labelText:" Birth Date",
                  labelStyle: TextStyle(fontSize: 20,fontStyle: FontStyle.normal)
                ),
                firstDate: DateTime.now().add(const Duration(days: 10)),
                lastDate: DateTime.now().add(const Duration(days: 40)),
                initialPickerDateTime: DateTime.now().add(const Duration(days: 20)),
                onChanged: (DateTime? value) {
                  // selectedDate = value;
                },
              ),
                      ),
                  SizedBox(height: 15),
                  CustomTextFormField(
                    label: " Age",
                    controller: age,
                    keyboardType: TextInputType.number,
                  ),
                  SizedBox(height: 15),
                  CustomTextFormField(
                    label: "Name/type of disease",
                    controller: type,
                    keyboardType: TextInputType.text,
                  ),
                  SizedBox(height: 15),
                  const SizedBox(height: 8),
                  ElevatedButton(
                onPressed: () {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      backgroundColor: Colors.green,
      behavior: SnackBarBehavior.fixed, // Set behavior to fixed
      content: Center(child: Text(' Saved successfully !',style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold),)),
    ),
  );
},

                    child: Text(
                      " Save Information",
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
