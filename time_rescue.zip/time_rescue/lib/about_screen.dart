import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class About_Screen extends StatefulWidget {
  const About_Screen({super.key});

  @override
  State<About_Screen> createState() => _About_ScreenState();
}

List<IconData> NavIcons = [
  Icons.camera_enhance_outlined,
  Icons.home_filled,
  Icons.account_circle_outlined
];
int Item_Is_Selected = 0;

class _About_ScreenState extends State<About_Screen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      body: Stack(
        children: [
          Column(
children: [
  Row(mainAxisAlignment: MainAxisAlignment.start,
    children: [Image.asset("assets/logo.jpg",width: 200,height: 200,)]),
    SizedBox(height: 50,),
Center(child:Text("TimeRescue",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),),
              SizedBox(
                height: 30,
              ),
              Center(child:  Expanded(
                child: DefaultTabController(
                    length: 2,
                    child:
                
                        Center(
                          child: Container(
                            height: 50,
                            width: 350,
                            decoration: BoxDecoration(
                                color: Color.fromARGB(255, 155, 155, 155),
                                borderRadius: BorderRadius.circular(25.0)),
                            child: TabBar(
                              indicator: BoxDecoration(
                                  color: Color.fromARGB(255, 243, 242, 241),
                                  borderRadius: BorderRadius.circular(20.0)),
                              indicatorSize: TabBarIndicatorSize
                                  .tab, // تحديد حجم ثابت للـ indicator
                              labelColor: const Color.fromARGB(255, 190, 8, 8),
                              unselectedLabelColor: Color.fromARGB(255, 253, 252, 252),
                              tabs: const [
                                Tab(
                                  child: Text(
                                    'Content',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Poppins',
                                      height: 0.05,
                                      letterSpacing: -0.50,
                                    ),
                                  ),
                                ),
                                Tab(
                                  child: Expanded(
                                    child: Text(
                                      'About Time Rescue',
                                      style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'Poppins',
                                        height: 0.05,
                                        letterSpacing: -0.50,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                    ),
              ),
                
              )
],

          ),
// creation of Navigation bar
          Align(
            alignment: Alignment.bottomCenter,
            child: _navBar(),
          )
        ],
      ),
    );
  }

  Widget _navBar() {
    return Container(
      height: 65,
      margin: EdgeInsets.only(right: 24, left: 24, bottom: 24),
      decoration: BoxDecoration(
          color: Color.fromARGB(255, 242, 242, 242),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withAlpha(29),
                blurRadius: 20,
                spreadRadius: 10)
          ]),
   child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: NavIcons.map((icon) {
          int index = NavIcons.indexOf(icon);
          bool isSelected = Item_Is_Selected == index;

          return Material(
            color: Colors.transparent,
            child: GestureDetector(
              onTap: () => setState(() {
                    Item_Is_Selected = index;
                  }),
              child: Column(
                children: [
                  Container(
                    alignment: Alignment.center,
                    margin: EdgeInsets.only(top: 15, bottom: 0, left: 35, right: 35),
                    child: Icon(
                      icon,
                      color: isSelected ? Colors.blue : Colors.black,
                    ), 
                        )
                  ],
                ),
            ),
            );
          }).toList(),
   
      ),
    );
  }
}
